<?php
@(include('config.php')) or header('Location:setup.php');
?>
<!DOCTYPE html>
<html>
    <head>
        <title>404</title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
            <link rel="stylesheet" href="bootstrap.css"/>
            <link rel="stylesheet" href="main.css"/>
        </head>
        <body style="padding-top:60px">
            <div class="navbar navbar-inverse navbar-fixed-top">
                <a class="navbar-brand" href="<?php require_once('req.php');echo 'http://'.$wsa;?>"><?php echo $wsn;?></a>
                <ul class="nav navbar-nav">
                    <li><a href="//github.com/Cydrobolt/polr">Polr Github</a></li>
                </ul>
            </div>
            <div class="container">
                <div class="jumbotron" style="padding-top:80px; background-color: rgba(0,0,0,0);">
                    <h1>Welcome to your Polr Instance</h1><br>
                    <?php
                    if ($wp==1) {
                        echo "<p style='color: red'>Your Polr instance is improperly configured. Delete config.php and reinstall.</p>";
                    }
                    else {
                        echo "<p style='color: green'>Your Polr instance is properly configured.</p>";
                    }
                    ?>
                    <br>If you need help, click <a href="http://webchat.freenode.net/?channels=#polr">here</a><br>
                <br><br><b>Clueless? Read the docs. <a href='https://github.com/Cydrobolt/polr/tree/master/docs'>https://github.com/Cydrobolt/polr/tree/master/docs</a></b></div>
            </div>
                       <footer>
                <p><?php echo $footer;?></p>
            </footer>
        </div>
    </body>
</html>
