<?php

require_once('req.php');

echo var_dump($mysqli);
