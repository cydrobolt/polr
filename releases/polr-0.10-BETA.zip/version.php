<?php
$version = "0.10 Beta Release";
$reldate = "2/14/2014";