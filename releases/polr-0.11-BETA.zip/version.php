<?php
$version = "0.11 Beta Release";
$reldate = "2/14/2014";