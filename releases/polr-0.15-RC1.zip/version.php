<?php
$version = "0.15 RC1";
$reldate = "2/15/2014";